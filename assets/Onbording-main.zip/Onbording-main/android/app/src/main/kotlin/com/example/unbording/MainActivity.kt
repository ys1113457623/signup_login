package com.example.unbording

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
